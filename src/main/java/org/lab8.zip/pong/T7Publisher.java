package org.pong;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

/**
* Publishes data to the cloud with mqtt 
* 
* @author Jude Shin 
* 
*/
public class Publisher implements Runnable {
  private final static String BROKER = "tcp://broker.hivemq.com:1883";
  private final static String TOPIC = "cal-poly/csc/307/meee";
  private final static String CLIENT_ID = "god-sender";

  @Override
  public void run() {
    try {
      MqttClient client = new MqttClient(BROKER, CLIENT_ID);
      client.connect();
      System.out.println("Connected to BROKER: " + BROKER);

			// we can maybe make this a listener
			// every time that the datarepository is changed, then you can push the data
      int counter = 0;
      while (true) {
        String content = (Repository.getInstance().getX()) + "," + (Repository.getInstance().getY());
        MqttMessage message = new MqttMessage(content.getBytes());
        message.setQos(2);
        if (client.isConnected())
          client.publish(TOPIC, message);
        counter++;
        System.out.println("Message published: " + content);
        Thread.sleep(5000);
      }
    } catch (MqttException | InterruptedException e) {
      e.printStackTrace();
    }
  }
}

